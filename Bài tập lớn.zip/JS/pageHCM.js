$(document).ready(function() {
	$(window).scroll(function() {
		if ($(this).scrollTop()) {
			$('#backtop').fadeIn();
		}
		else {
			$('#backtop').faeOut();
		}
	});
	$('backtop').click(function() {
		$('html, body').animate({
			scrollTop: 0
		}, 500);
	});
});